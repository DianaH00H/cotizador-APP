# FLI Cotizador

Sistema de cotizacion de fletes nacionales para FLIHolding.
Desarrollado con Streamlit y un modelo de Machine Learning (XGBoost / Random Forest).

## Estructura

```
fli-cotizador/
├── Home.py                      # Login y pantalla principal
├── pages/
│   ├── 1_Cotizacion.py          # Formulario de cotizacion (rol: carrier)
│   └── 2_Tickets.py             # Gestion de tickets (rol: ventas)
├── model/
│   └── modelo_final.pkl         # Modelo entrenado
├── data/
│   └── tickets.csv              # Registro de tickets generados
├── utils.py                     # Utilidades y estilos compartidos
├── requirements.txt
└── .streamlit/
    └── config.toml              # Tema visual
```

## Usuarios

| Usuario | Contrasena  | Rol     |
|---------|-------------|---------|
| carrier | carrier123  | carrier |
| ventas  | ventas123   | ventas  |

## Despliegue en Streamlit Cloud

1. Sube este repositorio a GitHub.
2. Ve a https://streamlit.io/cloud y conecta el repo.
3. Selecciona `Home.py` como archivo principal.
4. Despliega.

## Modelo

El modelo fue entrenado con datos historicos de operaciones nacionales de FLIHolding.
Para actualizar el modelo, corre los scripts de entrenamiento y reemplaza `model/modelo_final.pkl`.
